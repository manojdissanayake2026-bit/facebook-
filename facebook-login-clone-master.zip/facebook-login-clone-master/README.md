# facebook-login-clone

A responsive clone of Facebook login page using HTML & CSS for computer screen and mobile screen.

### You can see a live demo [here](https://facebook.ashishbhatia.dev/).

<br><div style="text-align:center;">
  <a href="https://ab-facebook.netlify.app/" target="\_parent"><img src="./images/readme.png" alt="facebook-login-clone" style="width:450px;"/></a>
</div>

Disclaimer : Cloned for educational purposes only.
